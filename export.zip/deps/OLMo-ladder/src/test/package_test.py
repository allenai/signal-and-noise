def test_package():
    assert True
