### Unreleased

- Added infra for consistent rankings project
- Moved some of the fitting scripts from /scripts to /fitting so they can be imported
- Added a two-parameter setup without the bias E term
- Added a negated setup for fitting with FLOPs
- Handling for various edge cases