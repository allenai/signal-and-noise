# Created from SNR subtask analysis
SMOOTH_SUBTASKS = {
    "mmlu": [
        "prehistory",
        "world_religions",
        "high_school_psychology",
        "miscellaneous",
        "conceptual_physics",
        "astronomy",
        "high_school_government_and_politics",
        "college_biology",
        "philosophy",
        "high_school_biology",
        "high_school_microeconomics",
        "anatomy",
        "medical_genetics",
        "logical_fallacies",
        "human_aging",
    ],
    "autobencher": ["science", "history", "biology", "cognitive", "chemistry"],
}
